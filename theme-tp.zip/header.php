<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4W4-Voyage</title>
    <!-- <link rel="stylesheet" href="normalize.css"> -->
    <link rel="stylesheet" href="style.css">
    <!-- <?php bloginfo('stylesheet_url'); ?> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <?php wp_head(); ?>
</head>

<body>
    <header>
        <div class="header-container">
            <figure class="logo">
                <img src="<?php echo get_template_directory_uri() . '/assets/logo/logo.png' ?>" alt="Logo">
            </figure>
            <nav class="navigation">
                <ul class="menu">
                    <li><a href="#">Aventure</a></li>
                    <li><a href="#">Sportive</a></li>
                    <li><a href="#">Culturelle</a></li>
                    <li><a href="#">Familiale</a></li>
                    <li><a href="#">Gastronomique</a></li>
                    <li><a href="#">Bien-être</a></li>
                    <li><a href="#">Romantique</a></li>
                    <li><a href="#">Musicale</a></li>
                </ul>
            </nav>
            <?php get_search_form() ?>
        </div>
    </header>